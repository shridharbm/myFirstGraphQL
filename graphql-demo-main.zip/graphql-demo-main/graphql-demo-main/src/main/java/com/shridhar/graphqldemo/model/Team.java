package com.shridhar.graphqldemo.model;

public enum Team {
    CSK,
    MI,
    DC,
    GT,
    RCB
}
