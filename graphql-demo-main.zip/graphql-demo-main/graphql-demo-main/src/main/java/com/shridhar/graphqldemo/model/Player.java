package com.shridhar.graphqldemo.model;

public record Player(Integer Id, String name, Team team) {
}
